#include "device_driver.h"
#include "st7735.h"
#define BASE  (500) //msec

RCC_ClocksTypeDef RCC_ClockFreq;

extern volatile int Key_Value;
extern volatile int TIM4_Expired;
extern volatile int ADC1_value;
extern volatile int ADC1_flag;

int enable = 1;
int temp = 22;

int main(void)
{ 
	RCC_GetClocksFreq(&RCC_ClockFreq);
	
	int adc_interlock, duration;
	int AD_value;
	signed char x, y, z;
	
  enum key{C1, C1_, D1, D1_, E1, F1, F1_, G1, G1_, A1, A1_, B1, C2, C2_, D2, D2_, E2, F2, F2_, G2, G2_, A2, A2_, B2};
  enum note{N64=BASE/16,N32=BASE/8,N16=BASE/4, N8=BASE/2, N4=BASE, N2=BASE*2, N1=BASE*4};
  const char * note_name[] = {"C1", "C1#", "D1", "D1#", "E1", "F1", "F1#", "G1", "G1#", "A1", "A1#", "B1", "C2", "C2#", "D2", "D2#", "E2", "F2", "F2#", "G2", "G2#", "A2", "A2#", "B2"};
  
  Uart1_Init(115200);
	ADC1_Init();
	ADC1_ISR_Enable(1,9);
  TIM3_Buzzer_Init();
	Key_ISR_Enable(1);
  
  Uart1_Printf("%s ", note_name[C1]);
  TIM3_Buzzer_Beep(C1,N16);
  TIM1_Delay(10);
  Uart1_Printf("%s ", note_name[D1]);
  TIM3_Buzzer_Beep(D1,N16);
  TIM1_Delay(10);
  Uart1_Printf("%s ", note_name[E1]);
  TIM3_Buzzer_Beep(E1,N16);
  TIM1_Delay(10);
	
  Uart1_Init(115200);
  I2C_Setup();
	Lcd_Init();
  TIM_Config(); 
  LED_Init();
  Key_Poll_Init();
	Ethernet_Init();
	
	TIM4_Repeat_Interrupt_Enable(1, 200);
	
	
  for(;;)
  {
		
		
		loopback_tcps_v2(0, 5000);
		
    if(TIM4_Expired)
    {
      TIM4_Expired = 0;
      x = I2C_getbyte(0x38,0x29); //X-axis to read..
      y = I2C_getbyte(0x38,0x2b); //Y-Axis to read..
      z = I2C_getbyte(0x38,0x2d); //Z Axis to read..
			if(z<0)
			{    
				Lcd_Set_Trans_Mode(0);
				Lcd_Set_Shape_Mode(0,0);
        
				Lcd_Printf(10,10,GREEN,RED,1,1,"Car is overturn!!");
				
			}
			else
			{
				Lcd_Set_Trans_Mode(0);
				Lcd_Set_Shape_Mode(0,0);
        
				
			}
			
			if ( Key_Value == 1 ) // key0�� �����ٸ�
			{
				TIM4_Expired = 0;
				ADC1_ISR_Start();
			}
		}
		
		if(ADC1_flag)
		{
			AD_value = ADC1_value;
			Uart1_Printf("The current AD value = %f \r\n", AD_value);
			
			if ( AD_value < 500 ) 
			{      
                                Lcd_Printf(10,10,GREEN,RED,1,1,"Car Crash!!"); // ��ǥ, ��, ??
				TIM3_Buzzer_Init();
				TIM3_Buzzer_Beep(C1, 0);
				Lcd_Set_Trans_Mode(0);
				Lcd_Set_Shape_Mode(0,0);
				
			}
			
			else if ( 500 <= AD_value && AD_value < 1500 ) 
			{ 
				TIM3_Buzzer_Init();  
				TIM3_Buzzer_Beep(C1,50);
				TIM1_Delay(50);
				TIM3_Buzzer_Beep(C1,50);
				TIM1_Delay(50);
				
				Lcd_Set_Trans_Mode(0);
				Lcd_Set_Shape_Mode(0,0);
				Lcd_Printf(10,10,GREEN,RED,1,1,"Warning!"); // ��ǥ, ��, ??
			}
			
			else if ( 1500 <= AD_value && AD_value < 4500 )
			{ 
				TIM3_Buzzer_Init();  
				TIM3_Buzzer_Beep(C1,100);
			}
			else {
				TIM3_Buzzer_Init(); 
				TIM3_Buzzer_Beep(C1,100);
				
			}
			ADC1_flag = 0;
		}
		
		if( Key_Value == 2 )
		{
			Lcd_Clr_Screen(RED);
			Lcd_Printf(10,10,GREEN,RED,1,1,"AUTO : %d", temp++);
			Key_Value = 0;
		}
		
		if( Key_Value == 4 )
		{
			Lcd_Clr_Screen(RED);
			Lcd_Printf(10,10,GREEN,RED,1,1,"AUTO : %d", temp--);
			Key_Value = 0;
		}
	}
}